import simulateProgress from "@/utils/simulateProgress";
import { Dispatch, SetStateAction, useRef, useState } from "react";

type LoadingType = {
  totalProgress: number;
  isLoading: boolean;
  setTotalProgress: Dispatch<SetStateAction<number>>;
  setIsLoading: Dispatch<SetStateAction<boolean>>;
};

const loading = ({
  setTotalProgress,
  totalProgress,
  setIsLoading,
  isLoading,
}: LoadingType) => {
  const step = simulateProgress(setTotalProgress);
  console.log("totalProgress in loading: ", totalProgress);

  const progressRef = { current: 0 };

  const update = (value: number) => {
    progressRef.current = value;
    setTotalProgress(value);
  };

  const tick = () => {
    setTotalProgress((prev) => {
      // prev هنا هي القيمة الحالية للـ progress قبل التحديث
      let next = prev >= 100 ? 100 : step(); // step() يعطينا التقدّم الجديد

      if (next >= 100) {
        clearInterval(timerId);
        setIsLoading(false);
      }

      progressRef.current = next; // نحتفظ بآخر قيمة حقيقية
      return next;
    });
  };

  const timerId = setInterval(tick, 500);

  return {
    clearLoading: () => clearInterval(timerId),
  };

  // let interval: NodeJS.Timeout;
  // const intervalFn = () => {
  //   if (totalProgress >= 100) {
  //     clearInterval(interval);
  //     setIsLoading(false);
  //   } else {
  //     const progress = step();
  //     setTotalProgress(progress);
  //   }
  // };

  // interval = setInterval(intervalFn, 500);

  // return {
  //   isLoading,
  //   progress: totalProgress,
  //   clearLoading: () => {
  //     clearInterval(interval);
  //     if (totalProgress < 100) {
  //       interval = setInterval(intervalFn, 500);
  //     } else setIsLoading(false);
  //   },
  // };
};

const useLoading = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [progress, setProgress] = useState(0);

  const timerRef = useRef<NodeJS.Timeout>(null);

  const start = () => {
    setIsLoading(true);

    const step = simulateProgress(setProgress);

    timerRef.current = setInterval(() => {
      setProgress((prev) => {
        const next = prev >= 100 ? 100 : step();
        if (next >= 100) {
          clear();
        }
        return next;
      });
    }, 500);
  };

  const clear = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsLoading(false);
  };
  console.log("totalProgress: ", progress);
  return {
    progress,
    isLoading,
    start,
    clear,
  };
};

export default useLoading;
